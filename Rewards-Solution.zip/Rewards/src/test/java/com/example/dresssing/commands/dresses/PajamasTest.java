package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class PajamasTest {
    @Test
    public void forWeather() throws Exception {
        assertThat(new Pajamas().forWeather(Weather.HOT)).isEqualTo(Pajamas.PAJAMAS);
        assertThat(new Pajamas().forWeather(Weather.COLD)).isEqualTo(Pajamas.PAJAMAS);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Pajamas().canBeDressed(Weather.HOT)).isTrue();
        assertThat(new Pajamas().canBeDressed(Weather.COLD)).isTrue();
    }


}