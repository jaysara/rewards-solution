package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class HeadwearTest {
    @Test
    public void forWeather() throws Exception {
        assertThat(new Headwear().forWeather(Weather.HOT)).isEqualTo(Headwear.SUNGLASSES);
        assertThat(new Headwear().forWeather(Weather.COLD)).isEqualTo(Headwear.HAT);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Headwear().canBeDressed(Weather.HOT)).isTrue();
        assertThat(new Headwear().canBeDressed(Weather.COLD)).isTrue();
    }

}