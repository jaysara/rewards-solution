package com.example.dresssing;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Unit test for simple App.
 */
public class AppTest 

{
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(System.out);
        System.setErr(System.err);
    }




    @Test
    public void testApp_Success()
    {

        App app = new App();
        String[] args = {"HOT", "8", "6,", "4,", "2,", "1,", "7"};
        app.main(args);
        Assertions.assertThat(outContent.toString()).startsWith("Output: Removing PJs, shorts, shirt, sunglasses, sandals, leaving house");
    }
}
