package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class SocksTest {

    @Test
    public void forWeather() throws Exception {
        assertThat(new Socks().forWeather(Weather.HOT)).isEqualTo(Socks.FAILS);
        assertThat(new Socks().forWeather(Weather.COLD)).isEqualTo(Socks.SOCKS);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Socks().canBeDressed(Weather.HOT)).isFalse();
        assertThat(new Socks().canBeDressed(Weather.COLD)).isTrue();
    }

}