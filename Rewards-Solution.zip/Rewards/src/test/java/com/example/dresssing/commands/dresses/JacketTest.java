package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class JacketTest {
    @Test
    public void forWeather() throws Exception {
        assertThat(new Jacket().forWeather(Weather.HOT)).isEqualTo(Jacket.FAILS);
        assertThat(new Jacket().forWeather(Weather.COLD)).isEqualTo(Jacket.JACKET);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Jacket().canBeDressed(Weather.HOT)).isFalse();
        assertThat(new Jacket().canBeDressed(Weather.COLD)).isTrue();
    }

}