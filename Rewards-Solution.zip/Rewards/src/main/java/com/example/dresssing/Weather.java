package com.example.dresssing;

import com.example.dresssing.commands.DressCommand;

import java.util.List;

public enum Weather {
    HOT,
    COLD;

    public boolean isDressedProperly(List<DressCommand> commands){
        if (this.equals(HOT))
            return commands.size()==5;
        else return commands.size()==7;
    }
}
