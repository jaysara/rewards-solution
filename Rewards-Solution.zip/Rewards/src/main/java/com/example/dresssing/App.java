package com.example.dresssing;

import java.util.Arrays;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        if(args.length < 2)
        {
            System.err.println("At least one argument must be supplied");
            System.exit(0);
        }
        String output = new GetDressed().startDressing(args);
        System.out.println(String.format("Output: %s ", output));
    }
}
