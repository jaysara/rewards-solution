package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Footwear implements DressCommand {

    Weather weather;
    static final String SANDALS = "sandals";
    static final String BOOTS = "boots";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? SANDALS : BOOTS;
    }


    @Override
    public boolean canBeDressed(Weather weather) {
        return true;
    }


}
