package com.example.dresssing;


import com.example.dresssing.commands.CommandCreator;
import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.commands.InvalidCommandException;
import com.example.dresssing.commands.dresses.Pajamas;

import java.util.*;
import java.util.stream.Collectors;

public class GetDressed {

    public static final String FAIL = "fail";

    private List<DressCommand> history = new ArrayList<>();

    private Weather dressingFor;

    /**
     * //startDressingFor(Weather).byTakingOffPajamasFirst().putOn(String[]).andgo();
     * This is the only public method availabke to process the commands.
     * @param inputCommands
     * @return
     */
    public String startDressing(String[] inputCommands)
    {
        try {

            startDressingForWeather( inputCommands[0], inputCommands[1])
                    .putOnItems(Arrays.copyOfRange(inputCommands, 2, inputCommands.length-1))
                    .andGo(inputCommands[inputCommands.length-1]);
            return printHistory();
        }
        catch (IllegalArgumentException ila)
        {
            String printHistory = printHistory();

            return printHistory.isEmpty() ? FAIL: String.join(",",printHistory,FAIL);
        }
        catch (InvalidCommandException e) {

            String printHistory = printHistory();
            return printHistory.isEmpty() ? FAIL: String.join(", ",printHistory,FAIL);

        }

    }


    /**
     * Prints the contents of all historical commands for the output purpose.
     * @return
     */
    private String printHistory(){
        return history.stream().map(command -> command.forWeather(dressingFor)).collect(Collectors.joining(", "));
    }

    /**
     * This functions executes all the command that has to do with putting on actual cloths. It maintains the state of the object.
     * @param wearCommands
     * @return this object
     * @throws InvalidCommandException
     */
    private GetDressed putOnItems(String[] wearCommands) throws InvalidCommandException {

        for(int i=0; i< wearCommands.length;i++)
            putOn(wearCommands[i]);
        return this;
    }

    /**
     * Initializes the state. and ensures that proper weather information has been supplied.
     * @param weather
     * @param pajamaCommand
     * @return
     * @throws InvalidCommandException
     */
    protected GetDressed startDressingForWeather(String weather, String pajamaCommand) throws InvalidCommandException {
        String[] weatherCommand = weather.split(" ");


        this.dressingFor = Weather.valueOf(weather);
        return byTakingOffPajamasFirst(pajamaCommand);

    }

    /**
     * First command has to be to take off the pajams. This function ensures that this command is supplied properly.
     * @param command
     * @return
     * @throws InvalidCommandException
     */
    private GetDressed byTakingOffPajamasFirst(String command) throws InvalidCommandException {


        assert dressingFor!=null:"Weather must have been set before taking off Pajamas";


        Optional<DressCommand> dressCommand = CommandCreator.createCommand(command);
        if (dressCommand.isPresent()&& dressCommand.get().getClass().equals(Pajamas.class))
                 history.add(dressCommand.get());
        else throw new InvalidCommandException("Not Taking-off Pajama command");
        return this;
    }



    /**
     * This is the last command. Ensures that all cloths are put on according to the weather and we are ready to leave house.
     * @param command
     * @throws InvalidCommandException
     */
    private void andGo(String command) throws InvalidCommandException
    {
        assert dressingFor!=null:"Weather must have been set before taking off Pajamas";
        assert history.size() > 0 : " Taking off Pajamas command must have been issued before putting on anything";
        if(dressingFor.isDressedProperly(history))
            runCommand(command);
        else throw new InvalidCommandException("All cloths must be put on as per the weather");
    }


    /**
     * This function handles the proper command has been supplied to put on specific cloths.
     * @param command
     * @throws InvalidCommandException
     */
    protected void putOn(String command) throws InvalidCommandException {
        assert dressingFor!=null:"Weather must have been set before taking off Pajamas";
        assert history.size() > 0 : " Taking off Pajamas command must have been issued before putting on anything";
        runCommand(command);


    }


    /**
     * This is the actual logic function that ensures that the proper dress command is issues that is allowed in the current state.
     * If any of the required conditions is not met, InvalidCommandException will be throuwn.
     * @param command
     * @throws InvalidCommandException
     */
    private void runCommand(String command) throws InvalidCommandException {
        Optional<DressCommand> dressCommand =
                CommandCreator.createCommand(command);
        if(dressCommand.isPresent() &&
                dressCommand.get().canBeDressed(dressingFor)) {
            if (history.contains(dressCommand.get()))
                throw new InvalidCommandException("Dress has already been worn!!");
            history.add(dressCommand.get());
        }
        else throw new InvalidCommandException("Invalid command" );
    }

}
