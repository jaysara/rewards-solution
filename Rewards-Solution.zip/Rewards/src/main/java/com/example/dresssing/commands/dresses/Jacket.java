package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Jacket implements DressCommand {

    Weather weather;
    static final String FAILS = "fail";
    static final String JACKET = "jacket";

    public String forWeather(Weather weather) {
        return weather.equals(Weather.HOT) ? FAILS : JACKET;
    }


    @Override
    public boolean canBeDressed(Weather weather) {
        return !forWeather(weather).equals(FAILS);
    }
}
