package com.example.dresssing.commands;

import com.example.dresssing.Weather;

public interface DressCommand {

    public boolean canBeDressed(Weather weather);

    public String forWeather(Weather weather);
}
