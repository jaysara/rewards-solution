package com.example.dresssing.commands;

public class InvalidCommandException extends Exception {

    public InvalidCommandException(String message)
    {
        super(message);
    }
}
