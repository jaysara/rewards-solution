package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Pants implements DressCommand {

    Weather weather;
    static final String PANTS = "pants";
    static final String SHORTS = "shorts";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? SHORTS : PANTS;
    }


    @Override
    public boolean canBeDressed(Weather weather) {
        return true;
    }
}
