package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Headwear implements DressCommand {

    Weather weather;
    static final String SUNGLASSES = "sunglasses";
    static final String HAT = "hat";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? SUNGLASSES : HAT;
    }
    @Override
    public boolean canBeDressed(Weather weather) {
        return true;
    }
}
