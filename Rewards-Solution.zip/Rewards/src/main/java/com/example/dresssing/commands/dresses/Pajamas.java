package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Pajamas implements DressCommand {

    Weather weather;
    static final String PAJAMAS = "Removing PJs";

    public String forWeather(Weather weather)
    {
        return PAJAMAS;
    }


    @Override
    public boolean canBeDressed(Weather weather) {
        return true;
    }
}
