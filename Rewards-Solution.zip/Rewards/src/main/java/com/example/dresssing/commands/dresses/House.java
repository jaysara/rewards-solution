package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class House implements DressCommand {

    Weather weather;
    static final String LEAVING_HOUSE = "leaving house";

    public String forWeather(Weather weather)
    {
        return LEAVING_HOUSE;
    }


    @Override
    public boolean canBeDressed(Weather weather) {
        return true;
    }
}
