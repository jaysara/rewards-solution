package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

public class Socks implements DressCommand {

    Weather weather;
    static final String FAILS = "fail";
    static final String SOCKS = "socks";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? FAILS : SOCKS;
    }

    @Override
    public boolean canBeDressed(Weather weather) {
        return !forWeather(weather).equals(FAILS);
    }
}
