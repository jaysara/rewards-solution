package com.example.dresssing;

import com.example.dresssing.commands.CommandCreator;
import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.commands.InvalidCommandException;
import com.example.dresssing.commands.dresses.House;
import com.example.dresssing.commands.dresses.Pajamas;
import org.jooq.lambda.Seq;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class GettingDressed {

    final static String FAIL = "fail";

    /**
     * //startDressingFor(Weather).byTakingOffPajamasFirst().putOn(String[]).andgo();
     * This is the only public method availabke to process the commands.
     * @param inputCommands
     * @return
     */
    public String startDressing(String[] inputCommands)
    {
            Weather dressingFor = Weather.getWeather(inputCommands[0]);

            List<String> historyCommands = new ArrayList<>();
            if(dressingFor != null && CommandCreator.isPajamaCommand(inputCommands[1]))
                historyCommands.add(Pajamas.PAJAMAS);
            else return FAIL;

            return Seq.of(Arrays.copyOfRange(inputCommands, 2, inputCommands.length))
                    .foldLeft(historyCommands, new CommandProcessorFunction(historyCommands, dressingFor))
                    .stream().collect(Collectors.joining(", "));


    }

    /**
     * BiFunction to process the command and retunr the output for foldLeft
     */
    private static class CommandProcessorFunction implements BiFunction<List<String>, String, List<String>> {
        private final List<String> historyCommands;
        private final Weather dressingFor;

        public CommandProcessorFunction(List<String> historyCommands, Weather dressingFor) {
            this.historyCommands = historyCommands;
            this.dressingFor = dressingFor;
        }

        @Override
        public List<String> apply(List<String> dressCommands, String command) {

            if(historyCommands.contains("fail"))
                return historyCommands;

            try {
                Optional<DressCommand> dressCommand = CommandCreator.createCommand(command);

                if(dressCommand.isPresent() && dressCommand.get().canBeDressed(dressingFor, historyCommands))
                    historyCommands.add(dressCommand.get().forWeather(dressingFor));

                else historyCommands.add(FAIL);

                return historyCommands;
            } catch (InvalidCommandException e) {

                historyCommands.add("fail");
            }

            return historyCommands;
        }
    }
}
