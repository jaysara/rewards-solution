package com.example.dresssing.commands;

import com.example.dresssing.Weather;

import java.util.List;

public interface DressCommand {

    static final String NOT_ALLOWED = "INVALID";

    default boolean isNotPresent(Weather weather,List<String> history)
    {
        return !history.contains(forWeather(weather));
    }

    public boolean canBeDressed(Weather weather, List<String> history);

    public String forWeather(Weather weather);
}
