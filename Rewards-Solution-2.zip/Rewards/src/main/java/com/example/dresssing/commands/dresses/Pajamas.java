package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

import java.util.List;

public class Pajamas implements DressCommand {

    Weather weather;
    public static final String PAJAMAS = "Removing PJs";

    public String forWeather(Weather weather)
    {
        return PAJAMAS;
    }


    @Override
    public boolean canBeDressed(Weather weather, List<String> history) {
        return isNotPresent(weather,history);
    }
}
