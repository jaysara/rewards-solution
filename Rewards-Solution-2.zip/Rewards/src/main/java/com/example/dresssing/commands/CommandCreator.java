package com.example.dresssing.commands;

import com.example.dresssing.commands.dresses.*;

import java.util.*;
import java.util.stream.Collectors;

public class CommandCreator {

    @SuppressWarnings("serial")
    private final static Map<Integer, DressCommand> DressCommandMap =

         Collections.unmodifiableMap(new HashMap<Integer, DressCommand>() {
            {
                put(1, new Footwear());
                put(2, new Headwear());
                put(3, new Socks());
                put(4, new Shirt());
                put(5, new Jacket());
                put(6, new Pants());
                put(7,new House());
                put(8, new Pajamas());


            }
        });


    /**
     * The input command may have ',' as part of the input based on the program arguments.
     * This utility method discards ',' at the last place and create a command.
     * @param command
     * @return
     * @throws InvalidCommandException
     */
    public static Optional<DressCommand> createCommand(String command) throws InvalidCommandException{
           try {
               String commandDigit = command;
               if(command.indexOf(",")>0)
                commandDigit=   command.substring(0,command.indexOf(","));
               return Optional.ofNullable(DressCommandMap.get(Integer.valueOf(commandDigit.trim())));


           }catch (NumberFormatException nfe){
               throw new InvalidCommandException("Not a valid number "+command);
           }
    }

    /**
     * Utility methods to parse the inputs and create comma separated list
     * @param inputCommands
     * @return
     */
    public static List<String> parseInputCommands(String inputCommands)
    {
        return Collections.list(new StringTokenizer(inputCommands, ",")).stream()
                .map(token -> (String) token)
                .collect(Collectors.toList());
    }


    /**
     * Utility method to determine if comamnd is of type Pajama
     * @param command
     * @return
     */
    public static boolean isPajamaCommand(String command){

        return isCommandForClass(command,Pajamas.class);

    }

    /**
     * Utility method to determine if comamnd is of type Pajama
     * @param command
     * @return
     */
    public static boolean isLeavingHouseCommand(String command){

        return isCommandForClass(command,House.class);

    }
    /**
     * Utility method to determine if comamnd is of type Pajama
     * @param command
     * @return
     */
    public static boolean isCommandForClass(String command,Class dressCommandClass){

        try {
            Optional<DressCommand> dressCommand = CommandCreator.createCommand(command);
            return  (dressCommand.isPresent()&& dressCommand.get().getClass().equals(dressCommandClass));
        } catch (InvalidCommandException e) {
            e.printStackTrace();
        }
        return false;

    }
}
