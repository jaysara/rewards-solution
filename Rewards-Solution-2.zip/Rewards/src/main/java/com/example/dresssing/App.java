package com.example.dresssing;

import com.example.dresssing.commands.CommandCreator;
import org.jooq.lambda.Seq;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        if(args.length < 2)
        {
            System.err.println("At least one argument must be supplied");
            System.exit(0);
        }
        String output = new GettingDressed().startDressing(args);
        System.out.println(String.format("Output: %s ", output));
    }
}
