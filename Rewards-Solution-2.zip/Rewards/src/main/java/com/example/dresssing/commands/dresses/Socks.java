package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

import java.util.List;

public class Socks implements DressCommand {

    Weather weather;

    static final String SOCKS = "socks";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? NOT_ALLOWED : SOCKS;
    }

    @Override
    public boolean canBeDressed(Weather weather, List<String> history) {
        return  isNotPresent(weather,history) && !forWeather(weather).equals(NOT_ALLOWED);
    }
}
