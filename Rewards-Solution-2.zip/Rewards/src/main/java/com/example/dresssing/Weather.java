package com.example.dresssing;

import com.example.dresssing.commands.DressCommand;

import java.util.List;

public enum Weather {
    HOT,
    COLD;

    public boolean isDressedProperly(List commands){
        if (this.equals(HOT))
            return commands.size()==5;
        else return commands.size()==7;
    }

    public static boolean isValid(String weather){
        return weather != null;
    }

    public static Weather getWeather(String weather){
        try{
           return  Weather.valueOf(weather);
        }catch (IllegalArgumentException ilae){
            return null;
        }
    }
}
