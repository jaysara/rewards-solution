package com.example.dresssing.commands.dresses;

import com.example.dresssing.commands.DressCommand;
import com.example.dresssing.Weather;

import java.util.List;

public class Footwear implements DressCommand {

    Weather weather;
    static final String SANDALS = "sandals";
    static final String BOOTS = "boots";

    public String forWeather(Weather weather)
    {
        return weather.equals(Weather.HOT) ? SANDALS : BOOTS;
    }


    @Override
    public boolean canBeDressed(Weather weather, List<String> history) {
        return  isNotPresent(weather,history);
    }


}
