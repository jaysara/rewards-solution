package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.*;

public class FootwearTest {
    @Test
    public void forWeather() throws Exception {
        assertThat(new Footwear().forWeather(Weather.HOT)).isEqualTo(Footwear.SANDALS);
        assertThat(new Footwear().forWeather(Weather.COLD)).isEqualTo(Footwear.BOOTS);
    }

    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Footwear().canBeDressed(Weather.HOT, new ArrayList<String>())).isTrue();
        assertThat(new Footwear().canBeDressed(Weather.COLD,new ArrayList<String>() )).isTrue();
    }

}