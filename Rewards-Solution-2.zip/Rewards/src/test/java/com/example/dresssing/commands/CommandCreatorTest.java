package com.example.dresssing.commands;

import com.example.dresssing.commands.dresses.*;
import org.junit.Test;

import java.util.Arrays;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

public class CommandCreatorTest {
    @Test
    public void createCommand() throws Exception {

        Optional<DressCommand> dressCommand = CommandCreator.createCommand("8");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Pajamas.class);

        dressCommand = CommandCreator.createCommand("1");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Footwear.class);

        dressCommand = CommandCreator.createCommand("1,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Footwear.class);

        dressCommand = CommandCreator.createCommand("2");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Headwear.class);

        dressCommand = CommandCreator.createCommand("3");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Socks.class);

        dressCommand = CommandCreator.createCommand("4");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Shirt.class);

        dressCommand = CommandCreator.createCommand("5");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Jacket.class);

        dressCommand = CommandCreator.createCommand("6");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Pants.class);

        dressCommand = CommandCreator.createCommand("7");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(House.class);

        dressCommand = CommandCreator.createCommand("2,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Headwear.class);

        dressCommand = CommandCreator.createCommand("3,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Socks.class);

        dressCommand = CommandCreator.createCommand("4,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Shirt.class);

        dressCommand = CommandCreator.createCommand("5,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Jacket.class);

        dressCommand = CommandCreator.createCommand("6,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(Pants.class);

        dressCommand = CommandCreator.createCommand("7,");
        assertThat(dressCommand.isPresent()).isTrue();
        assertThat(dressCommand.get().getClass()).isEqualTo(House.class);


    }

    @Test
    public void testCommandParsing()
    {
        String[] inputCommands = {"HOT","8,","6," ,"4,","2,","1,","7"};
        assertThat(Arrays.copyOfRange(inputCommands, 2, inputCommands.length)).containsExactly("6," ,"4,","2,","1,","7");

    }

}