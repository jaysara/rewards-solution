package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.assertj.core.util.Lists;
import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

public class HouseTest {
    @Test
    public void forWeather() throws Exception {
        assertThat(new House().forWeather(Weather.HOT)).isEqualTo(House.LEAVING_HOUSE);
        assertThat(new House().forWeather(Weather.COLD)).isEqualTo(House.LEAVING_HOUSE);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new House().canBeDressed(Weather.HOT, new ArrayList<String>())).isFalse();
        assertThat(new House().canBeDressed(Weather.COLD, new ArrayList<String>())).isFalse();
        assertThat(new House().canBeDressed(Weather.HOT, Lists.newArrayList( "6", "4", "2", "1", "7"))).isTrue();

    }

}