package com.example.dresssing.commands.dresses;

import com.example.dresssing.Weather;
import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

public class PantsTest {

    @Test
    public void forWeather() throws Exception {
        assertThat(new Pants().forWeather(Weather.HOT)).isEqualTo(Pants.SHORTS);
        assertThat(new Pants().forWeather(Weather.COLD)).isEqualTo(Pants.PANTS);
    }


    @Test
    public void canBeDressed() throws Exception {
        assertThat(new Pants().canBeDressed(Weather.HOT, new ArrayList<String>())).isTrue();
        assertThat(new Pants().canBeDressed(Weather.COLD, new ArrayList<String>())).isTrue();
    }

}