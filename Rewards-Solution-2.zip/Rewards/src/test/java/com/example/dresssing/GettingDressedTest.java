package com.example.dresssing;


import com.example.dresssing.commands.InvalidCommandException;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.util.Collections;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.*;

public class GettingDressedTest {


    @Test
    public void test_WeatherIsSuppliedInFirst_Argument(){
        final String input ="HOTS 8, 6, 4, 2, 1, 7";
       // new StringTokenizer(input," ")
        String[] inputCommands = getStringArrayOfInputArguments(input);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(GettingDressed.FAIL);

    }

    public static String[] getStringArrayOfInputArguments(String input) {
        String[] inputCommands = new String[7] ;
        Collections.list(new StringTokenizer(input, " ")).stream()
                .map(token -> (String) token)
                .collect(Collectors.toList()).toArray(inputCommands);
        return inputCommands;
    }

    private String[] getStringArrayOfInputArguments(String input, int expectedElements) {
        String[] inputCommands = new String[expectedElements] ;
        Collections.list(new StringTokenizer(input, " ")).stream()
                .map(token -> (String) token)
                .collect(Collectors.toList()).toArray(inputCommands);
        return inputCommands;
    }

    @Test
    public void testPajamasOff_IsFirstCommand(){
        final String input ="HOT 2, 6, 4, 2, 1, 7";
        String[] inputCommands = getStringArrayOfInputArguments(input);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(GettingDressed.FAIL);
    }

    @Test
    public void test_DuplicateCommands(){
        final String input ="HOT 8, 6, 6, 2, 1, 7";
        String[] inputCommands = getStringArrayOfInputArguments(input);
        String expectedOutput = "Removing PJs, shorts, fail";
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

    @Test
    public void test_NoSocks_inHotWeather(){

        String input ="HOT 8, 6, 4, 2, 5, 7";
        String expectedOutput = "Removing PJs, shorts, shirt, sunglasses, fail";
        String[] inputCommands = getStringArrayOfInputArguments(input);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

    @Test
    public void test_noJacket_inHotWeather(){
        String input ="HOT 8, 6, 3, 4, 2, 5, 7";
        String expectedOutput = "Removing PJs, shorts, fail";
        String[] inputCommands = getStringArrayOfInputArguments(input,8);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

    @Test
    public void test_AllDressedBefore_GointOut(){
        String input ="COLD 8, 6, 3, 4, 2, 5, 7";
        String expectedOutput  = "Removing PJs, pants, socks, shirt, hat, jacket, fail";
        String[] inputCommands = getStringArrayOfInputArguments(input,8);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

    @Test
    public void test_Success_ForHotWeahter()
    {
        String input = "HOT 8, 6, 4, 2, 1, 7";
        String expectedOutput  = "Removing PJs, shorts, shirt, sunglasses, sandals, leaving house";
        String[] inputCommands = getStringArrayOfInputArguments(input);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

    @Test
    public void test_Success_ForColdWeahter()
    {
        String input = "COLD 8, 6, 3, 4, 2, 5, 1, 7";
        String expectedOutput  = "Removing PJs, pants, socks, shirt, hat, jacket, boots, leaving house";
        String[] inputCommands = getStringArrayOfInputArguments(input,9);
        GettingDressed dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);

        input = "COLD 8, 6, 5, 4, 2, 3, 1, 7";
         expectedOutput  = "Removing PJs, pants, jacket, shirt, hat, socks, boots, leaving house";
        inputCommands = getStringArrayOfInputArguments(input,9);
         dressed = new GettingDressed();
        Assertions.assertThat(dressed.startDressing(inputCommands)).isEqualTo(expectedOutput);
    }

//    @Test
//    public void test_putOn() throws Exception
//    {
//        GettingDressed getDressed = new GettingDressed();
//        assertThatThrownBy(()->getDressed.putOn("8"));
//        assertThatExceptionOfType(AssertionError.class).isThrownBy(()->getDressed.putOn("3"));
//
//
//    }
//
//    @Test
//    public void test_startDressingForWeather() throws Exception
//    {
//        GettingDressed getDressed = new GettingDressed();
//        assertThat(getDressed.startDressingForWeather("HOT","8")).isInstanceOf(GettingDressed.class);
//        assertThatCode(() ->{getDressed.putOn("2");}).doesNotThrowAnyException();
//
//        assertThatExceptionOfType(InvalidCommandException.class).isThrownBy(()->getDressed.putOn("3"));
//
//    }

}