package com.example.dresssing;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.junit.Assert.*;

public class WeatherTest {

    @Test
    public void testWeatherEnum()
    {
        String hot = "HOT";
        assertThat(Weather.valueOf(hot)).isEqualTo(Weather.HOT);

        String cold = "COLD";
        assertThat(Weather.valueOf(cold)).isEqualTo(Weather.COLD);

        //Weather.valueOf(hot).equals(Weather.HOT);
    }

    @Test
    public void testInValid_WeatherEnum()
    {
        String cloudy = "CLOUDY";
        assertThatIllegalArgumentException().isThrownBy(()->{Weather.valueOf(cloudy);});

    }
}